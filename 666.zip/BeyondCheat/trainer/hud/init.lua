--HUD stuff here

--TO DO: Remake it from whitelist

bc_require('trainer/tools/workspace')

local bc_dofile = bc_dofile
local bc_config = bc_config
local ExGUIObject = ExGUIObject

local managers = managers
local M_gui = managers.gui_data

--Init object
--Confused about choose of workspace, seems 16_9 like a correct one since menu uses cutted workspace size
local bc_obj = ExGUIObject:new( GameSetup and M_gui:create_fullscreen_workspace() or M_gui:create_fullscreen_16_9_workspace() )

local G = getfenv(0)
G.bc_obj = bc_obj

bc_obj.__elements = {}

--bc_obj:setup_mouse() --Temporary debug

--Wrapped requires into separate function for update_object()
local function exec()
	--Version text
	if bc_config.HUD_VersionText and MenuSetup then
		bc_dofile('trainer/hud/version_text')
	end
end

--Called when resolution changed
function bc_obj:update_object()
	bc_obj:destroy()
	bc_obj = ExGUIObject:new( GameSetup and M_gui:create_fullscreen_workspace() or M_gui:create_fullscreen_16_9_workspace() )
	G.bc_obj = bc_obj
	bc_obj.__elements = {}
	--bc_obj:setup_mouse() --Temporary debug
	exec()
end

exec()