--Purpose: initiates autostart scripts here, depending on configuration.
--Note: Scripts here being executed both in game and in pre-game.

--Preloading values from table. You will face more of these preloads in other script files.
--This should increase speed of executing script at all trading off some RAM, because accessing locals & upvalues are much faster, than iterating and comparing with each hash from current table.
local bc_require = bc_require

local managers = managers
local tweak_data = tweak_data
local Global = Global
local backuper = backuper
local backup = backuper.backup
local hijack = backuper.hijack
local os_clock = os.clock
local io_open = bc_io.open
local tab_insert = table.insert
local bc_dofile = bc_dofile
local pairs = pairs

local is_server = is_server()

local cfg = bc_config

if cfg.DisableAnticheat then
	bc_require 'trainer/addons/disable_anticheat'
end

if cfg.DLCUnlocker then
	bc_require 'trainer/addons/dlc_unlocker'
end

if cfg.EnableDebug then
	bc_require 'trainer/addons/debugenable'
end

if cfg.FreeAssets then
	backup(backuper, 'MoneyManager.get_mission_asset_cost_by_id')
	function MoneyManager.get_mission_asset_cost_by_id()return 0 end --Free assets

	for _, asset in pairs(tweak_data.crime_spree.assets) do
		asset.cost = 0
	end
end

if cfg.FreePreplanning then
	bc_require 'trainer/addons/freepreplanning'
end

if cfg.FreeCrimeSpree then
	bc_require 'trainer/addons/freecrimespree'
end

if cfg.HostMatters and is_server then
	bc_require 'trainer/addons/hostchooseplan'
end

if cfg.NoDropinPause then
	bc_require('trainer/addons/nopause')
end

if cfg.NoStatsSynced then
	function NetworkAccountSTEAM.publish_statistics()end
end

if cfg.AllPerks then
	bc_require 'trainer/addons/all_perks'
end

if cfg.DisableAutoKick then
	Global.game_settings.auto_kick = false
end

if cfg.AllSkins then
	bc_require 'trainer/addons/all_skins'
end

if cfg.CrewUnlocker then
	bc_require 'trainer/addons/crew_unlocker'
end

--Notices users, if crash happened.
if cfg.ExceptionsCrashDetect and managers.exception then
	bc_require 'trainer/menu/crashnoticer'
end

if cfg.EnableJobFix then
	bc_require 'trainer/addons/jobfix'
end

if cfg.freed_hoxton then
	bc_require 'trainer/addons/unlock_hoxton'
end

if cfg.earned_arbiter then
	bc_require 'trainer/addons/unlock_arbiter'
end

if cfg.completed_aldstone then
	bc_require 'trainer/addons/unlock_aldstone'
end

if cfg.SpoofCards and not Global.game_settings.single_player then
	bc_require('trainer/addons/spoof_cards')
end

bc_require 'trainer/addons/invisible_blt_mods'

--Requires user scripts
bc_require 'trainer/custom_auto'