--Purpose: initiates autostart in game scripts here, depending on configuration.

local bc_require = bc_require
local bc_dofile = bc_dofile

local is_client = is_client()
local is_server = is_server()

local managers = managers
local M_player = managers.player
local M_blackmarket = managers.blackmarket

local level_id = Global.game_settings.level_id

local in_game = in_game
local is_playing = is_playing

local backuper = backuper
local backup = backuper.backup
local plugins = plugins
local plug_require = plugins.bc_require

local query_execution_testfunc = query_execution_testfunc

local path = "trainer/addons/"
local load_plugin = load_plugin( path )

local cfg = bc_config

bc_require("trainer/addons/weap_fix1")

bc_dofile('trainer/auto_config')

--bc_require depending on bc_config scripts

if not cfg.DisableBulletFix then
	bc_require('trainer/addons/bulletfix')
end

local ControlLevel = cfg.ControlCheats
if ControlLevel and ((is_client and ControlLevel == 1) or ControlLevel >= 2) then --Autostart equipment control
	plug_require(plugins, 'trainer/equipment_stuff/equipment_control', true)
end

if cfg.NoInvisibleWalls and is_server then -- No invisible walls (Host only)
	query_execution_testfunc(is_playing,{ f = function() bc_dofile 'trainer/addons/no_invisible_walls.lua' end })
end

if cfg.RestartProMissions and is_server then -- Restart pro missions (it also includes RestartJobs)
	bc_require('trainer/addons/restart_pro_missions.lua')
end

if cfg.RestartJobs and is_server then
	bc_require('trainer/addons/restart_jobs')
end

if cfg.NoEscapeTimer and is_server then -- No escape timer (Host only) (By Harfatus)
	backup(backuper, 'ElementPointOfNoReturn.on_executed')
	function ElementPointOfNoReturn.on_executed() end
end

if cfg.NoCivilianPenality then
	bc_require('trainer/addons/freecivilians')
end

if cfg.DontFreezeRagdolls then
	backup(backuper, 'CopActionHurt._freeze_ragdoll')
	function CopActionHurt._freeze_ragdoll()end
end

if cfg.DontDisposeRagdolls then
	backup(backuper, 'EnemyManager._upd_corpse_disposal')
	function EnemyManager._upd_corpse_disposal()end
end

if cfg.LaserColorR then
	bc_require('trainer/weapon_stuff/lasercolor')
end

if not cfg.DisableInvFix then
	bc_require('trainer/addons/invfix')
end

if cfg.far_placements then
	plug_require(plugins, 'trainer/equipment_stuff/long_placement', true)
end

if is_server and cfg.SecureAll then
	bc_require('trainer/addons/secureall')
end

if cfg.Crosshair then
	bc_require("trainer/addons/crosshair")
end

if is_server and (level_id == "chill" or level_id == "chill_combat") then
	bc_dofile("trainer/addons/customize_safehouse")
end

--Requires user scripts

bc_require('trainer/custom_game')