--[[
	Init file for some helpfull core functions.
	bc_require it before init.lua being executed.
]]

local bc_require = bc_require
local rawget = rawget
bc_require('trainer/tools/tools')

--Setup for underground light hook

local __require_after = rawget(_G, '__require_after')
if (__require_after) then
	local bc_dofile = bc_dofile
	local rawset = rawset
	local getmetatable = getmetatable
	local Application = Application
	
	__require_after['lib/entry'] = 
	function()
		--Inits trainer
		bc_dofile('trainer/init')
		--bc_dofile('trainer/freeflight')
	end

	__require_pre['core/lib/system/coresystem'] =
	function()
		--Enables freeflight
		rawset(getmetatable(Application),"debug_enabled",function() return true end)
	end
end
