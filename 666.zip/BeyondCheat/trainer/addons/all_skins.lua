--  Purpose:  Gives you all skins
--  Authors:  Written by Simplity, fixes by The Joker
local pairs = pairs
local tostring = tostring

local M_blackmarket = managers.blackmarket
local weapon_skins = tweak_data.blackmarket.weapon_skins
local inventory_tradable = M_blackmarket._global.inventory_tradable

local backuper = backuper

local i = 1
local j = tostring(i)
for id, data in pairs( weapon_skins ) do
	while inventory_tradable[j] ~= nil do
		i = i + 1
		j = tostring(i)
	end
	if not M_blackmarket:have_inventory_tradable_item( "weapon_skins", id ) then
		M_blackmarket:tradable_add_item( j, "weapon_skins", id, "mint", true, 1 )
	end
end

backuper:backup('BlackMarketManager.tradable_update')
function BlackMarketManager.tradable_update()
end

backuper:backup('BlackMarketManager.armor_skin_unlocked')
function BlackMarketManager.armor_skin_unlocked()
	return true
end

backuper:backup('BlackMarketManager._remove_unowned_armor_skin')
function BlackMarketManager._remove_unowned_armor_skin()
	return false
end