function BlackMarketManager.has_unlocked_breech()
	return true, "bm_menu_locked_breech"
end
function BlackMarketManager.has_unlocked_ching()
	return true, "bm_menu_locked_ching"
end
function BlackMarketManager.has_unlocked_erma()
	return true, "bm_menu_locked_erma"
end
function GenericDLCManager.has_raidww2_clan()
	return true
end