--Hard jobs for everyone!
function JobManager.calculate_job_class()return 10 end

--Now you can see hard jobs too
Global.game_settings.search_appropriate_jobs = false