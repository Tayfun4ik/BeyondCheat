--Purpose: no penalities for killing civilian

backuper:backup('MoneyManager.civilian_killed')
function MoneyManager.civilian_killed()end