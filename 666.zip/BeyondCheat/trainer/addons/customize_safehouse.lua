-- Purpose:  Execution file of Safe House customizations
-- Author:  The Joker

local date = os.date
local math = math
local math_random = math.random
local math_randomseed = math.randomseed
local math_round = math.round
local pairs = pairs
local table = table
local tab_insert = table.insert
local tab_remove = table.remove
local tostring = tostring

local managers = managers
local M_custom_safehouse = managers.custom_safehouse
local M_experience = managers.experience
local M_money = managers.money
local M_sync = managers.sync

local alive = alive
local OG_update_offshore = OffshoreGui.update_offshore

local level_id = Global.game_settings.level_id

local bc_require = bc_require
local executewithdelay = executewithdelay
local is_playing = is_playing
local send_message = send_message
local StopLoopIdent = StopLoopIdent

local tr = Localization.translate

local bc_config = bc_config
local togg_vars = togg_vars

togg_vars.SafeHouseInvest = togg_vars.SafeHouseInvest == nil and bc_config.SafeHouseInvest or togg_vars.SafeHouseInvest
togg_vars.SafeHouseInvestAmt = togg_vars.SafeHouseInvestAmt == nil and bc_config.SafeHouseInvestAmt or togg_vars.SafeHouseInvestAmt
togg_vars.SafeHouseLego = togg_vars.SafeHouseLego == nil and bc_config.SafeHouseLego or togg_vars.SafeHouseLego

if not BeyondSafeHouse then
	BeyondSafeHouse = {}
end
local beyond_safehouse = BeyondSafeHouse

if level_id == 'chill' then
	if togg_vars.SafeHouseInvest then
		if not beyond_safehouse.SafeHouseInvest then
			beyond_safehouse.SafeHouseInvest = true
			if not beyond_safehouse.SafeHouseInvest_init then
				beyond_safehouse.SafeHouseInvest_init = true
				local offshore_guis = {}
				local text_offshore_gui = 'offshore_gui'
				local synced_units = M_sync._synced_units
				for unit_id, data in pairs(synced_units) do
					if data.type == text_offshore_gui and M_sync._units[unit_id] and M_sync._units[unit_id]._visible then
						offshore_guis[unit_id] = M_sync._units[unit_id]
					end
				end
				local offshore_limit = 1000000000000000000
				local function message_display(text)
					send_message(tr.safehouse_invest_title.." - "..text)
				end
				local previous_SafeHouseInvestAmt
				local invest_minimum
				local invest_big_pass
				local text_sep = ":  "
				local text_add = "+"
				local text_spacer = "    -    "
				local tag_invest_loop = 'safehouse_invest_loop'
				local function invest_process()
					if is_playing() then
						local offshore = M_money:offshore()
						if offshore < offshore_limit then
							if offshore > 0 then
								if togg_vars.SafeHouseInvestAmt ~= previous_SafeHouseInvestAmt then
									previous_SafeHouseInvestAmt = togg_vars.SafeHouseInvestAmt
									invest_minimum = 100 * (10^togg_vars.SafeHouseInvestAmt)
									invest_big_pass = togg_vars.SafeHouseInvestAmt > 5
								end
								if offshore >= invest_minimum then
									local now_date = date('!*t')
									math_randomseed(now_date.yday * (now_date.hour + 1) * (now_date.min + 1) * (now_date.sec + 1) * math_random())
									local ret_amount = math_round(math_random(-invest_minimum, invest_minimum), 100)
									if ret_amount ~= 0 then
										if ret_amount > 0 then
											local spending = M_money:total()
											if ret_amount == 1337 then
												M_custom_safehouse:add_coins(10)
												message_display(tr.safehouse_invest_lucky)
											elseif invest_big_pass and ret_amount > 1000000 and math_random() < 0.50 then
												M_custom_safehouse:add_coins(1)
												message_display(tr.safehouse_invest_coin)
											end
											M_money:_add_to_total(ret_amount)
											message_display(tr.cash..text_sep..text_add..M_experience:cash_string(M_money:total() - spending)..text_spacer..tr.offshore..text_sep..text_add..M_experience:cash_string(M_money:offshore() - offshore))
										else
											M_money:deduct_from_offshore(-ret_amount)
											message_display(tr.offshore..text_sep..M_experience:cash_string(M_money:offshore() - offshore))
										end
										local new_offshore = M_money:offshore()
										local remove_guis = {}
										for unit_id, data in pairs(offshore_guis) do
											if alive(data._unit) then
												OG_update_offshore(data, new_offshore)
												M_sync:add_synced_offshore_gui(unit_id, true, new_offshore)
											else
												tab_insert(remove_guis, unit_id)
											end
										end
										if #remove_guis > 0 then
											for _, unit_id in pairs(remove_guis) do
												tab_remove(offshore_guis, unit_id)
											end
										end
										executewithdelay(beyond_safehouse.SafeHouseInvest_exec, 2, tag_invest_loop)
									end
								else
									message_display(tr.safehouse_invest_min)
								end
							else
								message_display(tr.safehouse_invest_empty)
							end
						else
							message_display(tr.safehouse_invest_max)
						end
					else
						togg_vars.SafeHouseInvest = nil
						beyond_safehouse.SafeHouseInvest = nil
					end
				end
				local tag_invest_delay = 'safehouse_invest_delay'
				beyond_safehouse.SafeHouseInvest_exec = function()
					executewithdelay(invest_process, (270 * math_random()) + 28, tag_invest_delay)
				end
				beyond_safehouse.SafeHouseInvest_stop = function()
					StopLoopIdent(tag_invest_loop)
					StopLoopIdent(tag_invest_delay)
				end
			end
			local now_date = date('!*t')
			math_randomseed(now_date.yday * (now_date.hour + 1) * (now_date.min + 1) * (now_date.sec + 1) * math_random())
			beyond_safehouse.SafeHouseInvest_exec()
		end
	else
		if beyond_safehouse.SafeHouseInvest then
			beyond_safehouse.SafeHouseInvest = nil
			beyond_safehouse.SafeHouseInvest_stop()
		end
	end
end

if togg_vars.SafeHouseLego and not beyond_safehouse.SafeHouseLego then
	bc_config.LegoFile = 'custom_safehouse'
	local _, load_lego = bc_require('trainer/menu/ingame/lego_menu')
	if load_lego() then
		beyond_safehouse.SafeHouseLego = true
	else
		togg_vars.SafeHouseLego = nil
	end
end

