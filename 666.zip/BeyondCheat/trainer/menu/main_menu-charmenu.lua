-- Switch scripts between main menu and char menu

if (GameSetup) then
	return bc_dofile('trainer/menu/ingame/charmenu')
else
	return bc_dofile('trainer/menu/pre-game/main_menu')
end