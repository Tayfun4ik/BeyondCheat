local bc_dofile = bc_dofile
--Hack lines
if (not orig__dofile) then
	orig__dofile = bc_dofile
end
--End of hacks

bc_dofile('__require.lua') --Loading improved bc_require function
__first_require_clbk =
function()
	bc_dofile("trainer/pre_init")
	--Write here code that needs to be executed on very first bc_require.
end
print("test")
--[[
--Callbacks, these executed before bc_require script being executed
__require_pre[required_script] = callback_function

--Callbacks, these executed after required script being executed
__require_after[required_script] = callback_function2

--Callbacks, these will override whole bc_require
__require_override[required_script] = callback_function3
]]

--Anything else, that needs to be executed on newstate goes here. Keep in mind, that only lua libs are opened at this stage, none of game internal classes, objects, methods are initialized yet.