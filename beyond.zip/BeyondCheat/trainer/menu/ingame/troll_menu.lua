if ( not GameSetup ) then
	return
end

local bc_require = bc_require
bc_require 'trainer/tools/new_menu/menu'

local main_menu, interaction_with_other, interaction_with_id_menu, release_player, interaction_with_self,
	interaction_with_team, give_equipments, give_bags

local path = "trainer/addons/troll_menu/"

local managers = managers
local M_network = managers.network
local M_net_session = M_network:session()
local M_localization = managers.localization
local locale_text = M_localization.text
local locale_exists = M_localization.exists

local tweak_data = tweak_data

local M_enemy = managers.enemy
local M_fire = managers.fire
local G_timer = TimerManager:game()

local World = World
local W_spawn_unit = World.spawn_unit
local M_groupAI = managers.groupai
local T_levels = tweak_data.levels
local team_id = T_levels:get_default_team_ID("combatant")
local team_data = M_groupAI:state():team_data( team_id )
local spook_id = Idstring( "units/payday2/characters/ene_spook_1/ene_spook_1" )

-- Functions

local alive = alive
local m_log_error = m_log_error

function unit_from_id( id )
	local unit = M_net_session:peer( id ):unit()
	if alive(unit) then
		return unit
	else
		m_log_error('unit_from_id()','Peer',id,'is dead')
	end
end
local unit_from_id = unit_from_id

local pairs = pairs
local all_ladders = Ladder.ladders

local increase_ladder = function()
	for _,unit in pairs( all_ladders )  do
		local ladder = unit:ladder()
		if ladder then
			ladder:set_height( 10000 )
			ladder:set_width( 10000 )
		end
	end
end

local GetPlayerUnit = GetPlayerUnit
local M_player = managers.player

local function verify_player_id(id) --Verify, that player in-game and entered it
	if not managers.network:session() then 
		return false 
	end  
	return managers.network:session():peer(id) and managers.criminals:character_name_by_peer_id(id)
end

local PackageManager = PackageManager
local package_udata = PackageManager.unit_data

local World = World
local find_units_quick = World.find_units_quick
local delete_unit = World.delete_unit

local delete_units = function()
	for _,unit_data in pairs(find_units_quick(World, "all"))  do
		if package_udata( PackageManager, unit_data:name() ):network_sync() == "spawn" then
			delete_unit(World, unit_data)
		end
	end
end

local change_own_state = function(state)
	if alive( GetPlayerUnit() ) then
		M_player:set_player_state(state)
	else
		m_log_error('change_own_state()','You are dead.')
	end
end

local set_cops_on_fire = function()
	local weapon_unit = GetPlayerUnit():inventory():unit_by_selection(1)
	
	local all_enemies = M_enemy:all_enemies()
	for u_key, u_data in pairs( all_enemies ) do
		M_fire:add_doted_enemy( u_data.unit, G_timer:time(), weapon_unit, 10, 10 )
	end
end

-- Interact with other players

local rot0 = Rotation(0,0,0)

local teleport_to_player = function(id)
	local unit = unit_from_id(id)
	if unit then
		M_player:warp_to( unit:position(), rot0 )
	end
end

-- Give equipments
local give_equipment = bc_require( path .. 'spawn_equipments' )

-- Spawn bag
local give_bag = bc_require( path .. 'spawn_bags' )

-- Interact with players

release_player = function(id)
	if id == "all" then
		local s = managers.network:session()
		if not s then
			return
		end
		for _, peer in pairs(s._peers) do
			if peer:id() ~= s:local_peer():id() and verify_player_id(peer:id()) then 
				release_player(peer:id())
			end
		end
		return
	end
	IngameWaitingForRespawnState.request_player_spawn(id)
end

local spawn_spook = function( id )
	local unit = unit_from_id( id )
	if not unit then
		return
	end
	
	local unit = W_spawn_unit( World, spook_id, unit:position(), unit:rotation() )
	unit:brain():set_spawn_ai( { init_state = "idle" } )		
	unit:movement():set_team( team_data )
end

local Localization = Localization
local tr = Localization.translate

local open_menu
do
	local Menu = Menu
	local open = Menu.open
	open_menu = function( ... )
		return open(Menu, ...)
	end
end

local tab_insert = table.insert

-- Menu
--TO DO: Catch these details from tweak_data ?
give_equipments = function( id, back_f )
	local data = {
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_ammo_bag"), callback = give_equipment, data = { id, "ammo" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_doctor_bag"), callback = give_equipment, data = { id, "medic" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_equipment_ecm_jammer"), callback = give_equipment, data = { id, "ecm" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_trip_mine"), callback = give_equipment, data = { id, "trip_mine" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_sentry_gun"), callback = give_equipment, data = { id, "sentry" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_equipment_bodybags_bag"), callback = give_equipment, data = { id, "bodybag" } },
	}
	
	open_menu( { title = tr['troll_give_equipments'], button_list = data, back = back_f } )
end

give_bags = function( id, back_f )
	local data = {}
	local data_carry = tweak_data.carry
	local locale_text = M_localization.text
	local locale_exists = M_localization.exists
	
	for bag_id, bag_data in pairs( data_carry ) do
		local name_id = bag_data.name_id
		if name_id and locale_exists( M_localization, name_id ) then
			tab_insert( data, { text = tr['troll_give'] .. " " .. locale_text( M_localization, name_id ), callback = give_bag, data = { id, bag_id }, switch_back = true } )
		end
	end
	
	open_menu( { title = tr['troll_give_bags'], button_list = data, back = back_f } )
end

interaction_with_self = function()
	local data = {}
	for _,state in pairs( M_player:player_states() ) do
		if state ~= "fatal" and state ~= "bleed_out" and state ~= "bipod" and state ~= "driving" then
			tab_insert(data, { text = state, callback = change_own_state, data = state })
		end
	end
	
	open_menu( { title = tr['troll_change_own_state'], button_list = data, back = main_menu } )
end

local format_loc = Localization.text

interaction_with_id_menu = function( id, name )
	local back_f = function() interaction_with_id_menu( id, name ) end
	
	local data = { 
		{ text = tr['troll_release_player'], callback = release_player, data = id },
		{ text = tr['troll_teleport_to'], callback = teleport_to_player, data = id },
		{},
		{ text = tr['troll_give_equipments'], callback = give_equipments, data = { id, back_f }, menu = true },
		{ text = tr['troll_give_bags'], callback = give_bags, data = { id, back_f }, menu = true },
		{ text = tr['troll_spawn_spook'], callback = spawn_spook, data = id, host_only = true },
	}
	
	open_menu( { title = format_loc(Localization, 'troll_interact_with', name, id), button_list = data, back = interaction_with_other } )
end

interaction_with_team = function()
	local data = { 
		{ text = tr['troll_give_equipments'], callback = give_equipments, data = { "all", interaction_with_team }, menu = true },
		{ text = tr['troll_give_bags'], callback = give_bags, data = { "all", interaction_with_team }, menu = true },
		{},
		{ text = tr['troll_release_tm_from_jail'], callback = release_player, data = "all" },
	}
	
	open_menu( { title = tr['troll_interact_team'], button_list = data, plugin_path = path, back = interaction_with_other } )
end

interaction_with_other = function()
	local data = { 
		{ text = tr['troll_interact_team'], callback = interaction_with_team, menu = true },
		{},
	}
	
	local count_data = #data
	
	local session = M_network._session
	local lpeer_id = session._local_peer._id
	for _, peer in pairs( session._peers ) do
		local peer_id = peer._id
		if peer_id ~= lpeer_id then
			local peer_name = peer._name
			tab_insert( data, { text = format_loc(Localization, 'troll_interact_with', peer_name, peer_id ), callback = interaction_with_id_menu, data = { peer_id, peer_name }, menu = true } )
		end
	end
	
	if #data == count_data then
		tab_insert(data, { text = tr['troll_no_players'], callback = void })
	end
	
	open_menu( { title = tr['troll_interaction_with_other'], button_list = data, plugin_path = path, back = main_menu } )
end

main_menu = function()
	local data = { 
		{ text = tr['troll_interaction_with_other'], callback = interaction_with_other, menu = true },
		{ text = tr['troll_change_own_state'], callback = interaction_with_self, menu = true },
		{},
		{ text = tr['troll_cops_to_bulld'], host_only = true, plugin = "cops_to_bulld" },
		{ text = tr['troll_replace_cops'], host_only = true, plugin = "replace_cops" },
		{ text = tr['troll_increase_ladder'], callback = increase_ladder },
		{ text = tr['troll_del_units'], host_only = true, callback = delete_units },
		{ text = tr['troll_take_mask'], callback = change_own_state, data = "mask_off" },
		{ text = tr['troll_set_cops_on_fire'], callback = set_cops_on_fire },
	}
	
	open_menu( { title = tr['troll_menu'], plugin_path = path, button_list = data } )
end

return main_menu