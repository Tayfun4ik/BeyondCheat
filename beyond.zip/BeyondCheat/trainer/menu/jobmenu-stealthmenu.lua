-- Switch scripts between job menu and stealth menu

if ( GameSetup ) then
	return bc_dofile('trainer/menu/ingame/stealthmenu')
else
	return bc_dofile('trainer/menu/pre-game/jobmenu')
end