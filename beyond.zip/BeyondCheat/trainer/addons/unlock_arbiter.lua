--backuper:backup('TangoManager.has_unlocked_arbiter')
function TangoManager.has_unlocked_arbiter()
	return true
end