--bc_require core key config first
--Read trainer/keyconfig for default key configuration and documentation
local cfg=bc_require("trainer/keyconfig")

return cfg
